using System;
using System.Collections.Generic;

//A dataset in this case is essentially a list of some inputs and the correct answers for those inputs
public class Dataset
{
    Random rng = new Random();

    public List<List<double>> allData = new List<List<double>>();
    public List<List<double>> labels = new List<List<double>>();

    public Dataset()
    {
        
    }
    public Dataset(int a)
    {
        //a is the amount of data
        for (int i = 0; i < a; i++)
        {
            allData.Add(new List<double>());
            labels.Add(new List<double>());
        }
    }
    public void changeData(int a, double[] newInputs, double[] newLabel)
    {
        allData[a] = Miscellaneous.arrayToList(newInputs);
        labels[a] = Miscellaneous.arrayToList(newLabel);
    }
    public void shuffleData()
    {
        List<double> temp1 = new List<double>();
        List<double> temp2 = new List<double>();
        int randomIndex = 0;
        for (int i = 0; i < allData.Count; i++)
        {
            randomIndex = rng.Next(i, allData.Count);
            temp1 = allData[i];
            allData[i] = allData[randomIndex];
            allData[randomIndex] = temp1;

            temp2 = labels[i];
            labels[i] = labels[randomIndex];
            labels[randomIndex] = temp2;
        }
    }
    public void duplicateData(Dataset original) {
        allData = new List<List<double>>(original.allData);
        labels = new List<List<double>>(original.labels);
    }
}