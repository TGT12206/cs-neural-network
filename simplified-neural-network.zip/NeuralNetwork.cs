using System;
using System.Collections.Generic;

public class NeuralNetwork
{
    //the dataset it is currently looking at
    public Dataset data = new Dataset();

    public List<Layer> Layers = new List<Layer>();
    
    //current inputs
    public List<double> Inputs = new List<double>();
    
    //current correct results if applicable
    public List<double> Results = new List<double>();
    
    //the network's opinion/answer
    public List<double> Outputs = new List<double>();
    
    //this is a multiplier for how much it changes its thinking
    //if the value is too high it overshoots the right values and makes the learning slow
    //but if the value is too low it also makes the learning slow
    public double learningRate;

    public NeuralNetwork(int[] dimensions)
    {
        learningRate = 1;
        
        //we start the loop at 1 because the first layer because the inputs are typically kept pure
        //until the next layer, but it doesn't matter.
        for (int i = 1; i < dimensions.Length; i++)
        {
            Layers.Add(new Layer(dimensions[i], dimensions[i - 1]));
        }
    }

    //based on the current inputs, it goes through the network and re-evaluates the outputs
    public void feedForward()
    {
        Layers[0].inputs = Inputs;

        for (int i = 1; i < Layers.Count; i++)
        {
            Layers[i].inputs = new List<double>(Layers[i - 1].feedForward());
        }
        Layers[Layers.Count - 1].feedForward();
        Outputs = Layers[Layers.Count - 1].outputs;
    }
    
    //Used to test the network with a dataset
    public void feedForward(Dataset testingData, int a)
    {
        Inputs = testingData.allData[a];
        Layers[0].inputs = Inputs;
        for (int i = 1; i < Layers.Count; i++)
        {
            Layers[i].inputs = new List<double>(Layers[i - 1].feedForward());
        }
        Layers[Layers.Count - 1].feedForward();
        Outputs = Layers[Layers.Count - 1].outputs;
        Console.WriteLine("Input #" + a + " was: " + Miscellaneous.listToString(Inputs));
    }

    public void learn(List<double> inputValues, List<double> correctValues) {
        List<double> Inputs = inputValues;
        List<double> Results = correctValues;
        
        //Making a guess
        feedForward();
        
        #region Learning from how wrong the guess was
        //the output neurons check their answer against the correct
        //answer, do some math, and then store that value to quantify how wrong they were
        for (int i = 0; i < Layers[Layers.Count - 1].Neurons.Count; i++)
        {
            Layers[Layers.Count - 1].Neurons[i].error = Sigmoid.derivative(Layers[Layers.Count - 1].Neurons[i].output) * (Results[i] - Layers[Layers.Count - 1].Neurons[i].output) * learningRate;
        }
        
        //the inner neurons check what role they played in the error of the layer after them, and store that value
        for (int i = Layers.Count - 2; i >= 0; i--)
        {
            for (int j = 0; j < Layers[i].Neurons.Count; j++)
            {
                Layers[i].Neurons[j].error = Sigmoid.derivative(Layers[i].Neurons[j].output) * Layers[i + 1].weightedError(j) * learningRate;
            }
        }
        //every single neuron, starting with the outer ones, nudge their values in the right direction
        //determined by their error values
        for (int i = Layers.Count - 1; i >= 0; i--)
        {
            for (int j = 0; j < Layers[i].Neurons.Count; j++)
            {
                Layers[i].Neurons[j].adjustWeights();
            }
        }
        #endregion
    }
    public void train()
    {
        //shuffle the data to avoid simple memorization and biases
        data.shuffleData();
        
        //go through the entire shuffled data and learn about each example
        //i need to change this system later down the line because datasets can be thousands of examples long
        //and you don't need to go through every example every time
        for (int a = 0; a < data.allData.Count; a++)
        {
            Inputs = data.allData[a];
            Results = data.labels[a];

            learn(Inputs, Results);
        }
    }
}