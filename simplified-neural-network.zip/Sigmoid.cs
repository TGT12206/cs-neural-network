using System;

public static class Sigmoid
{
    //actual sigmoid function
    public static double output(double x)
    {
        return 1.0 / (1.0 + Math.Exp(-x));
    }

    //the input must be the output from the actual sigmoid function for this
    //derivative function to work because x is the answer from the sigmoid function
    public static double derivative(double x)
    {
        return x * (1 - x);
    }
}