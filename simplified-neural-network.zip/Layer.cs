using System;
using System.Collections.Generic;

//each layer is a column of neurons connected to the previous layer
public class Layer
{
    public List<Neuron> Neurons = new List<Neuron>();
    
    //the inputs are the outputs of the previous layer
    public List<double> inputs = new List<double>();
    
    //the outputs of every neuron of this layer, based on the inputs
    public List<double> outputs = new List<double>();

    //make a layer with some number of neurons (amount)
    //and the number of neurons from the last layer to be linked (previousAmount)
    public Layer(int amount, int previousAmount)
    {
        for (int i = 0; i < amount; i++)
        {
            Neurons.Add(new Neuron(previousAmount));
        }
    }
    
    //evaluate the output of this layer based on the inputs
    public List<double> feedForward()
    {
        outputs.Clear();
        for (int i = 0; i < Neurons.Count; i++)
        {
            Neurons[i].inputs = new List<double>(inputs);
            outputs.Add(Neurons[i].feedForward());
        }
        return outputs;
    }

    //required for the error calculation
    //basically take the error of each neuron and multiply by
    //how strong its connection is to the specified neuron in the upper layer
    public double weightedError(int index)
    {
        double output = 0;
        for (int i = 0; i < Neurons.Count; i++)
        {
            output += Neurons[i].error * Neurons[i].weights[index];
        }
        return output;
    }
}