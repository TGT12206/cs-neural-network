using System;
using System.Collections.Generic;

class main
{
    static void Main()
    {
        //how many neurons in each layer
        int[] dimensions = { 2, 3, 2 };

        //a dataset on how to add in binary, including overflow
        //overflow: (imagine you can only show 2 numbers on a screen. When you add 99 + 1 you get 00)
        Dataset add = new Dataset(4);
        add.changeData(0, new double[] { 0, 0 }, new double[] { 0, 1 });
        add.changeData(1, new double[] { 0, 1 }, new double[] { 1, 0 });
        add.changeData(2, new double[] { 1, 0 }, new double[] { 1, 1 });
        add.changeData(3, new double[] { 1, 1 }, new double[] { 0, 0 });

        NeuralNetwork NN = new NeuralNetwork(dimensions);

        double t = 1;
        
        //r is how many times it trains. 2000 works almost all the time, but 800 almost works
        int r = 2000;
        NN.data.duplicateData(add);
        NN.learningRate = t;

        for (int i = 0; i < r; i++)
        {
            NN.train();
        }
        for (int a = 0; a < 4; a++)
        {
            NN.feedForward(add, a);
            Console.WriteLine(Miscellaneous.listToString(NN.Outputs));
        }
    }
}