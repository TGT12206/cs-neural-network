using System;
using System.Collections.Generic;

//This is for functions that are useful but also don't warrant their own class
public static class Miscellaneous
{
    public static List<double> arrayToList(double[] array) {
        List<double> newList = new List<double>();
        for (int i = 0; i < array.Length; i++) {
            newList.Add(array[i]);
        }
        return newList;
    }
    public static string listToString(List<double> convert)
    {
        string output = "";
        foreach (double i in convert)
        {
            output += i + ", ";
        }
        return output;
    }
    public static string listToString(double[] convert)
    {
        string output = "";
        foreach (double i in convert)
        {
            output += i + ", ";
        }
        return output;
    }
}