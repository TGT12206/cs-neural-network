using System;
using System.Collections.Generic;

public class Neuron
{
    //a list of inputs given to the neuron
    public List<double> inputs = new List<double>();
    
    //multiply the inputs by the weights
    public List<double> weights = new List<double>();
    
    //how wrong is the neuron
    public double error;
    
    //what is its current answer
    public double currentOutput;

    //so imagine y = mx + b, bias is b but there's a bunch of x's (the inputs) and m's (the weights)
    private double biasWeight;

    private Random rng = new Random();

    public Neuron(int numberOfConnections)
    {
        for (int i = 0; i < numberOfConnections; i++)
        {
            weights.Add(rng.NextDouble());
        }
        biasWeight = rng.NextDouble();
    }

    public double output
    {
        get { return currentOutput; }
    }

    public double feedForward()
    {
        for (int i = 0; i < inputs.Count; i++)
        {
            currentOutput += weights[i] * inputs[i];
        }
        currentOutput = Sigmoid.output(currentOutput + biasWeight);
        return currentOutput;
    }
    public void adjustWeights()
    {
        for (int i = 0; i < weights.Count; i++)
        {
            weights[i] += error * inputs[i];
        }
        biasWeight += error;
    }
}